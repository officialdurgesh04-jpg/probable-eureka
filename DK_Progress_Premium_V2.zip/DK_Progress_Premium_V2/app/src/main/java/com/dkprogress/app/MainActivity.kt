package com.dkprogress.app

import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebSettings
import android.graphics.Color
import android.content.Intent
import android.net.Uri
import android.view.View
import android.widget.Toast
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private val prefs by lazy { getSharedPreferences("dk_progress_secure_local", MODE_PRIVATE) }

    inner class DkBridge {
        @JavascriptInterface
        fun loadState(): String = prefs.getString("state_json", "{}") ?: "{}"

        @JavascriptInterface
        fun saveState(json: String) {
            // Apply() writes to persistent local storage asynchronously and survives app restarts.
            prefs.edit().putString("state_json", json).apply()
        }

        @JavascriptInterface
        fun openExternal(url: String) {
            runOnUiThread {
                try {
                    val uri = Uri.parse(url)
                    if (uri.scheme == "https" && (uri.host?.endsWith("youtube.com") == true ||
                                uri.host?.endsWith("youtu.be") == true)) {
                        startActivity(Intent(Intent.ACTION_VIEW, uri))
                    } else {
                        Toast.makeText(this@MainActivity, "Link not allowed", Toast.LENGTH_SHORT).show()
                    }
                } catch (_: Exception) {
                    Toast.makeText(this@MainActivity, "Link open nahi ho saka", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    @Suppress("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(9, 10, 14)
        window.navigationBarColor = Color.rgb(9, 10, 14)
        window.decorView.systemUiVisibility = 0
        webView = WebView(this)
        webView.setBackgroundColor(Color.rgb(9, 10, 14))
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            loadsImagesAutomatically = true
            mediaPlaybackRequiresUserGesture = true
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            allowFileAccess = true
            allowContentAccess = true
        }
        webView.addJavascriptInterface(DkBridge(), "DKNative")
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: android.webkit.WebResourceRequest): Boolean {
                val uri = request.url
                if (uri.scheme == "https" && (uri.host?.endsWith("youtube.com") == true || uri.host?.endsWith("youtu.be") == true)) {
                    try { startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (_: Exception) {}
                    return true
                }
                return uri.scheme != "file"
            }
        }
        webView.webChromeClient = WebChromeClient()
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onPause() {
        if (::webView.isInitialized) webView.evaluateJavascript("try{save()}catch(e){}", null)
        super.onPause()
    }

    override fun onDestroy() {
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }
}
